let cenaAtual = 'fazenda';
let pontuacao = 0;

// Posições dos personagens
let fazendeiroX, fazendeiroY;
let compradorX, compradorY;

// Velocidade dos personagens
const velocidadePersonagem = 5;

// Variáveis de tempo para a chegada do comprador
let tempoInicioJogo;
const tempoParaCompradorChegar = 5000; // 5 segundos em milissegundos
let compradorJaChegou = false;

// Variáveis de diálogo
let dialogoAtivo = false;
let produtosVendidos = {
  trigo: false,
  milho: false
};
let produtosVendidosContagem = 2; // Quantidade de produtos vendidos para mudar de cena
const MIN_PRODUTOS_PARA_MUDAR_CENA = 2; // Venda 2 produtos (1 trigo, 1 milho) para mudar de cena

function setup() {
  createCanvas(900, 600); // Aumentei um pouco o canvas
  fazendeiroX = width / 4;
  fazendeiroY = height * 0.75;
  compradorX = width * 0.75;
  compradorY = height * 0.75;

  textAlign(CENTER, CENTER);
  textSize(20);

  tempoInicioJogo = millis(); // Guarda o tempo de início do jogo
}

function draw() {
  if (cenaAtual === 'fazenda') {
    desenhaFazenda();
    desenhaPersonagensFazenda();
    atualizaMovimentoPersonagens();
    gerenciaChegadaComprador();
    desenhaDialogoFazenda();
    desenhaPontuacao();
    verificaColisaoPersonagens();
  } else if (cenaAtual === 'mercado') {
    desenhaMercado();
    desenhaPontuacaoFinal();
  }
}

// --- Funções da Cena da Fazenda ---

function desenhaFazenda() {
  background(135, 206, 235); // Céu azul
  fill(124, 252, 0); // Gramado
  rect(0, height / 2, width, height / 2);

  // Sol
  fill(255, 255, 0);
  ellipse(width - 80, 80, 100, 100);

  // Árvores
  fill(139, 69, 19); // Tronco
  rect(100, height / 2 - 80, 20, 80);
  rect(width - 120, height / 2 - 80, 20, 80);
  fill(34, 139, 34); // Folhas
  ellipse(110, height / 2 - 120, 80, 80);
  ellipse(width - 110, height / 2 - 120, 80, 80);

  // Plantação de Trigo
  fill(245, 222, 179); // Cor de trigo
  rect(width / 2 - 200, height / 2 + 50, 150, 80);
  fill(0);
  text("Trigo", width / 2 - 125, height / 2 + 100);

  // Plantação de Milho
  fill(152, 251, 152); // Cor de milho
  rect(width / 2 + 50, height / 2 + 50, 150, 80);
  fill(0);
  text("Milho", width / 2 + 125, height / 2 + 100);

  // Área dos produtos para venda (visualização)
  fill(200, 200, 200, 150);
  rect(width / 2 - 200, height / 2 + 160, 150, 60, 10);
  rect(width / 2 + 50, height / 2 + 160, 150, 60, 10);
  fill(0);
  textSize(16);
  text("Saco de Trigo\nR$ 10", width / 2 - 125, height / 2 + 190);
  text("Espiga de Milho\nR$ 8", width / 2 + 125, height / 2 + 190);
  textSize(20); // Volta ao tamanho padrão
}

function desenhaPersonagensFazenda() {
  // Fazendeiro (simples)
  fill(255, 223, 196); // Pele
  ellipse(fazendeiroX, fazendeiroY - 40, 40, 40); // Cabeça
  fill(139, 69, 19); // Chapéu
  rect(fazendeiroX - 25, fazendeiroY - 60, 50, 10);
  fill(0, 100, 0); // Roupa verde
  rect(fazendeiroX - 15, fazendeiroY - 20, 30, 60);

  // Comprador da Cidade (simples, só desenha se já chegou)
  if (compradorJaChegou) {
    fill(255, 223, 196); // Pele
    ellipse(compradorX, compradorY - 40, 40, 40); // Cabeça
    fill(50, 50, 150); // Roupa azul mais "urbana"
    rect(compradorX - 15, compradorY - 20, 30, 60);
  }
}

function atualizaMovimentoPersonagens() {
  // Movimento do Fazendeiro (W, A, S, D)
  if (keyIsDown(87)) { // W
    fazendeiroY -= velocidadePersonagem;
  }
  if (keyIsDown(83)) { // S
    fazendeiroY += velocidadePersonagem;
  }
  if (keyIsDown(65)) { // A
    fazendeiroX -= velocidadePersonagem;
  }
  if (keyIsDown(68)) { // D
    fazendeiroX += velocidadePersonagem;
  }

  // Movimento do Comprador (Setas)
  if (compradorJaChegou) {
    if (keyIsDown(UP_ARROW)) {
      compradorY -= velocidadePersonagem;
    }
    if (keyIsDown(DOWN_ARROW)) {
      compradorY += velocidadePersonagem;
    }
    if (keyIsDown(LEFT_ARROW)) {
      compradorX -= velocidadePersonagem;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      compradorX += velocidadePersonagem;
    }
  }

  // Limitar personagens dentro da tela
  fazendeiroX = constrain(fazendeiroX, 20, width - 20);
  fazendeiroY = constrain(fazendeiroY, height / 2 + 20, height - 20);
  compradorX = constrain(compradorX, 20, width - 20);
  compradorY = constrain(compradorY, height / 2 + 20, height - 20);
}

function gerenciaChegadaComprador() {
  if (!compradorJaChegou && millis() - tempoInicioJogo > tempoParaCompradorChegar) {
    compradorJaChegou = true;
  }
}

function verificaColisaoPersonagens() {
  if (compradorJaChegou) {
    let distancia = dist(fazendeiroX, fazendeiroY, compradorX, compradorY);
    if (distancia < 70 && !dialogoAtivo) { // Se colidir e não houver diálogo ativo
      dialogoAtivo = true;
    }
  }
}

function desenhaDialogoFazenda() {
  if (dialogoAtivo) {
    fill(255, 255, 255, 220);
    rect(width / 2 - 250, 50, 500, 100, 10);
    fill(0);
    textSize(22);

    if (produtosVendidosContagem === 0) {
      text("Fazendeiro: Olá! Comprador: Oi! Quais os preços?", width / 2, 80);
      text("Trigo: R$10, Milho: R$8. Quer comprar? sim me dê 2 de cada", width / 2, 120);
    } else if (produtosVendidosContagem < MIN_PRODUTOS_PARA_MUDAR_CENA) {
      text("Certo. Próximo produto?", width / 2, 90);
    } else {
      text("Ótimo! Tudo pronto para o mercado!", width / 2, 90);
    }
  }
}

function desenhaPontuacao() {
  fill(0);
  textSize(24);
  text("Pontos: " + pontuacao, 120, 40);
}

// --- Funções da Cena do Mercado ---

function desenhaMercado() {
  background(220); // Cor de fundo do mercado
  fill(139, 69, 19); // Piso de madeira
  rect(0, height * 0.7, width, height * 0.3);

  fill(150); // Paredes
  rect(0, 0, width, height * 0.7);

  fill(255, 255, 200); // Iluminação
  ellipse(width / 2, 50, 100, 100);

  fill(0);
  textSize(36);
  text("Bem-vindo ao Mercado da Cidade!", width / 2, 100);

  // Prateleiras
  fill(139, 69, 19);
  rect(100, height / 2 - 80, 200, 150, 10); // Prateleira 1
  rect(width - 300, height / 2 - 80, 200, 150, 10); // Prateleira 2

  // Produtos processados (apenas se foram vendidos)
  if (produtosVendidos.trigo) {
    fill(210, 180, 140); // Cor de pão
    rect(150, height / 2 - 50, 100, 50); // Pão
    fill(0);
    textSize(18);
    text("Pão de Trigo", 200, height / 2 + 5);
  }

  if (produtosVendidos.milho) {
    fill(255, 255, 0); // Cor de bolo de milho
    rect(width - 250, height / 2 - 50, 100, 50); // Bolo de milho
    fill(0);
    textSize(18);
    text("Bolo de Milho", width - 200, height / 2 + 5);
  }
  textSize(20); // Volta ao tamanho padrão
}

function desenhaPontuacaoFinal() {
  fill(0);
  textSize(36);
  text("Pontuação Final: " + pontuacao, width / 2, height - 150);
  textSize(24);
  text("Conexão Campo-Cidade Festejada!", width / 2, height - 100);

  // Botão de Reiniciar
  fill(0, 150, 0);
  rect(width / 2 - 75, height - 50, 150, 40, 10);
  fill(255);
  text("Reiniciar", width / 2, height - 30);
}

// --- Interatividade ---

function mousePressed() {
  if (cenaAtual === 'fazenda' && dialogoAtivo) {
    // Área de clique para venda do trigo
    if (mouseX > width / 2 - 200 && mouseX < width / 2 - 50 &&
      mouseY > height / 2 + 160 && mouseY < height / 2 + 220 && !produtosVendidos.trigo) {
      pontuacao += 10;
      produtosVendidos.trigo = true;
      produtosVendidosContagem++;
      dialogoAtivo = false; // Fecha o diálogo após a venda
    }

    // Área de clique para venda do milho
    if (mouseX > width / 2 + 50 && mouseX < width / 2 + 200 &&
      mouseY > height / 2 + 160 && mouseY < height / 2 + 220 && !produtosVendidos.milho) {
      pontuacao += 8;
      produtosVendidos.milho = true;
      produtosVendidosContagem++;
      dialogoAtivo = false; // Fecha o diálogo após a venda
    }

    // Muda de cena se todos os produtos necessários forem vendidos
    if (produtosVendidosContagem >= MIN_PRODUTOS_PARA_MUDAR_CENA) {
      cenaAtual = 'mercado';
    }

  } else if (cenaAtual === 'mercado') {
    // Clique no botão de reiniciar
    if (mouseX > width / 2 - 75 && mouseX < width / 2 + 75 &&
      mouseY > height - 50 && mouseY < height - 10) {
      reiniciarJogo();
    }
  }
}

function reiniciarJogo() {
  cenaAtual = 'fazenda';
  pontuacao = 0;
  fazendeiroX = width / 4;
  fazendeiroY = height * 0.75;
  compradorX = width * 0.75;
  compradorY = height * 0.75;
  tempoInicioJogo = millis();
  compradorJaChegou = false;
  dialogoAtivo = false;
  produtosVendidos = {
    trigo: false,
    milho: false
  };
  produtosVendidosContagem = 0;
}

